1,2,3,4,5,6

3. UI slider used in both red square for changing size and magic arena for changing transparency, which goes with 4.

5. Is in 6. Triangle Arena. Click on the green box will erase all.